<?php
use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;
return new class extends Migration {public function up():void{Schema::table('users',function(Blueprint $table){$table->dropUnique('users_email_unique');$table->unique(['school_id','email'],'users_school_email_unique');});}public function down():void{Schema::table('users',function(Blueprint $table){$table->dropUnique('users_school_email_unique');$table->unique('email');});}};
